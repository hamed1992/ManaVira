import Home from './../containers/home/Home'
export default Home;
