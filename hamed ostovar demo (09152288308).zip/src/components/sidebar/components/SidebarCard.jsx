/** @format */

import React, { useState } from "react";
import { fadeIn, fadeInRight, GreenRipple } from "../../../utility";
import useAddToCart from "../../../hooks/useAddToCart";
import { motion } from "framer-motion";
function SidebarCard({ product }) {
  const [count, increment, setDefaultValue] = useAddToCart(0, product);
  return (
    <motion.div variants={fadeInRight} className='bg-white sidebar-card mb-10 relative card-frame'>
      <div className='card-holder'>
        <figure className='flex justify-start items-center'>
          <img src={product.pic} alt='pic' className='w-20 h-20 rounded-full' />
          <figcaption className='flex flex-col pl-6'>
            <h6 className='text-primary text-base font-semibold mb-2'>
              {product?.title}
            </h6>
            <span className='text-gray-500 text-md'>{product?.desc}</span>
          </figcaption>
        </figure>
        <span className='price-item'>${product?.price}</span>
        <div className='absolute add-btn'>
          <GreenRipple className='rounded-full oveflow-hidden flex justify-center items-center'>
            <button onClick={increment} className='text-white text-base rounded-full flex justify-center items-center'>
              +
            </button>
          </GreenRipple>
        </div>
      </div>
      <style jsx>
        {`
          .card-frame {
            height: 150px;
            border-radius: 29px;
            position: relative;
          }
          .card-holder {
            box-shadow: -9px 0px 29px rgba(229, 229, 229, 0.5);
            border-radius: 29px;
            padding: 35px;
            // transition:all ease 0.3s;
          }
          .price-item {
            position: absolute;
            transform: rotate(90deg) translateX(10px) translateY(-10px);
            opacity: 0;
            background: var(--primary-color);
            color: #fff;
            font-size: 14px;
            left: 0;
            top: 50px;
            padding: 5px 20px;
            border-radius: 20px;
            transition: inherite;
            z-index: 400;
          }
          .sidebar-card:hover .price-item {
            opacity: 1;
          }
          .sidebar-card:hover .card-holder {
            background: linear-gradient(
              44.39deg,
              #50c9c3 6.16%,
              #96deda 94.73%
            );
            padding-left: 80px;
            position: absolute;
            right: 0;
            top: 0;
            width: 115%;
            transition: all solid 0.4s;
          }
          .sidebar-card figcaption h6,
          .sidebar-card figcaption span {
            transition: inherite;
          }
          .sidebar-card:hover figcaption h6,
          .sidebar-card:hover figcaption span {
            color: #fff;
          }
          .add-btn button {
            width: 33px;
            height: 32px;
            background: #23a0a5;
            transition: all ease 0.6s;
          }
          .add-btn {
            width: 33px;
            height: 32px;
            bottom: 20px;
            right: 20px;
            transition: inherite;
          }
          .sidebar-card:hover .add-btn button {
            background: #fff;
            color: #23a0a5;
          }
        `}
      </style>
    </motion.div>
  );
}

export default SidebarCard;
