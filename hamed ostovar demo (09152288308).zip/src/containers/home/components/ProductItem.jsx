/** @format */

import { motion } from "framer-motion";
import React from "react";
import useAddToCart from "../../../hooks/useAddToCart";
import { fadeInUp, GreenRipple } from "../../../utility";

function ProductItem({ product }) {
  const [count, increment, setDefaultValue] = useAddToCart(0, product);
  return (
    <motion.li
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.9 }}
      variants={fadeInUp}
      className='product-card p-6'>
      <figure className='bg-white'>
        <img src={product.pic} alt={product?.title} className='w-full' />
        <figcaption>
          <h6 className=''>{product?.title}</h6>
          <span className='extra-desc'>Green Fruit Jelly</span>
          <div className='desc'>
            <p>{product.desc}</p>
          </div>
          <div className='flex justify-between items-center'>
            <span className='item-price text-white text-xl'>
              {product?.price}$
            </span>
            <GreenRipple className='rounded-full oveflow-hidden flex justify-center items-center addtobasket'>
              <button onClick={increment} className=' text-white text-base rounded-full flex justify-center items-center'>
                +
              </button>
            </GreenRipple>
          </div>
        </figcaption>
      </figure>
      <style jsx>{``}</style>
    </motion.li>
  );
}

export default ProductItem;
